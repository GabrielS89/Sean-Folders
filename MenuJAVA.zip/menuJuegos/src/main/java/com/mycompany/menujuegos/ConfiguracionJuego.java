
package com.mycompany.menujuegos;

import javax.swing.ImageIcon;


public class ConfiguracionJuego {


    private static String rutaExe;
    private static ImageIcon iconoBoton;

    public static void setRutaExe(String ruta) {
        rutaExe = ruta;
    }

    public static String getRutaExe() {
        return rutaExe;
    }

    public static void setIconoBoton(ImageIcon icono) {
        iconoBoton = icono;
    }

    public static ImageIcon getIconoBoton() {
        return iconoBoton;
    }


    
}
