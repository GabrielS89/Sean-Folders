
package com.mycompany.menujuegos;

public class Main {
    
 public static void main(String[] args)
    
 {
   
     new Inicio().setVisible(true);
     
 }    
 
}